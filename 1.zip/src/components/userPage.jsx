import React, { useState, useEffect } from "react";
import api from "../api";
import { useHistory } from "react-router-dom";

const UserPage = ({ userId }) => {
    const history = useHistory();
    const [user, setUser] = useState();
    useEffect(() => {
        api.users.getById(userId).then((data) => setUser(data));
    }, []);
    const handleReturn = () => {
        history.push("/users");
    };
    return (
        <div>
            <h2>{user ? user.label : `Loading...`}</h2>;
            <button
                onClick = {() => {
                    handleReturn();
                }}
            >
                Все пользователи
            </button>
        </div>
    );
};

export default UserPage;
