import React from "react";
// import { paginate } from "../utils/paginate";
// import Pagination from "./pagination";
// import api from "../api";
import PropTypes from "prop-types";
// import GroupList from "./groupList";
// import SearchStatus from "./searchStatus";
// import UsersTable from "./usersTable";
// import _ from "lodash";
import UserPage from "./userPage";
import UsersList from "./usersList";
import { useParams } from "react-router-dom";

const Users = () => {
    const params = useParams();
    const { userId } = params;
    return (
        <>
            {userId ? <UserPage userId={userId} /> : <UsersList />}
        </>
    );
};

Users.propTypes = {
    // users: PropTypes.arrayOf(PropTypes.object).isRequired,
    count: PropTypes.number
};
export default Users;
