import React from "react";

const MainPage = () => {
    return (
        <>
            <h1>Main Page</h1>
        </>
    );
};

export default MainPage;
