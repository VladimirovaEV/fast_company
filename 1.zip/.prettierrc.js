module.exports={
    "trailingComma": "es5",
    "tabWith": 4,
    "semi": true
}