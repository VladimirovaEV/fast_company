import UserPage from "./userPage";
export default UserPage;
